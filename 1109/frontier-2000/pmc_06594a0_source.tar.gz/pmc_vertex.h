/**
 ============================================================================
 Name        : Parallel Maximum Clique (PMC) Library
 Author      : Ryan A. Rossi   (rrossi@purdue.edu)
 Description : A general high-performance parallel framework for computing
               maximum cliques. The library is designed to be fast for large
               sparse graphs.

 Copyright (C) 2012-2013, Ryan A. Rossi, All rights reserved.

 Please cite the following paper if used:
   Ryan A. Rossi, David F. Gleich, Assefaw H. Gebremedhin, Md. Mostofa
   Patwary, A Fast Parallel Maximum Clique Algorithm for Large Sparse Graphs
   and Temporal Strong Components, arXiv preprint 1302.6256, 2013.

 See http://ryanrossi.com/pmc for more information.
 ============================================================================
 */

#ifndef PMC_VERTEX_H_
#define PMC_VERTEX_H_

using namespace std;

namespace pmc {
    class Vertex {
        private:
            int id, b;
        public:
            Vertex(int vertex_id, int bound): id(vertex_id), b(bound) {};

            void set_id(int vid)        { id = vid; }
            int get_id()                { return id; }

            void set_bound(int value)   { b = value; }
            int get_bound()             { return b; }
    };

    static bool decr_bound(Vertex v,  Vertex u) {
        return (v.get_bound() > u.get_bound());
    }
    static bool incr_bound(Vertex v,  Vertex u) {
        return (v.get_bound() < u.get_bound());
    };

    inline static void print_mc_info(vector<int> &C_max, double &sec) {
        cout << "*** [pmc: thread " << omp_get_thread_num() + 1;
        cout << "]   current max clique = " << C_max.size();
        cout << ",  time = " << get_time() - sec << " sec" <<endl;
    };
};
#endif
